# %%
magics::.__file__(print, TRUE)
modules::expose(file.path(.__file__, "test1.R"))
