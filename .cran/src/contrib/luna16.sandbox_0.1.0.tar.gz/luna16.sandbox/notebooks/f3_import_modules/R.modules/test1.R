magics::.__file__(function(x) {
  x
},
TRUE)
source(file.path(.__file__, "test2.R"))
