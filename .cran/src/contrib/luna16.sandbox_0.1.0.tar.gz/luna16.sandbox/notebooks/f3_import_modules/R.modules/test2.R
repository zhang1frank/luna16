magics::.__file__(function(x) {
  x
},
TRUE)
