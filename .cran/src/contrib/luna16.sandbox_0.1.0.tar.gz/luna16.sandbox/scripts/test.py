# %%
class Test:
  def __init__(self):
    print(self)

a = Test()
# %%
print(dir())
